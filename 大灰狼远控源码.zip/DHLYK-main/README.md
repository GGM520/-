# 大灰狼 远控 V9.5 附小马源码

> 该项目只分享大灰狼远控样本, 请勿用于任何非法用途. 如在使用本工具的过程中存在任何非法行为，需自行承担相应后果，本人将不承担任何法律及连带责任。 主控稳定，支持万台同时在线。
<p>
    <img alt="大灰狼图片" src="https://github.com/0xCuSO4/DHLYK/blob/main/images/1.png?raw=true"  style="max-width:100%;">
</p>
